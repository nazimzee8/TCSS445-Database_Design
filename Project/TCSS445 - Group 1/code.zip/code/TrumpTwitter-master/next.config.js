module.exports = {
    publicPath: '/_next/static/images/',
    outputPath: 'static/images/'
}