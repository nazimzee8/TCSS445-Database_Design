import React from 'react';
import Layout from "../components/myLayout";

export default function About() {
    return (
        <>
            <Layout>
            <h1 style = {{marginTop: '50px', textAlign: 'center'}}>Created By: </h1>
            <h2 style = {{textAlign: 'center'}}>Daniel</h2>
            <h2 style = {{textAlign: 'center'}}>Adam</h2>
            <h2 style = {{textAlign: 'center'}}>Sam</h2>
            <h2 style = {{textAlign: 'center'}}>Nazim</h2>
            </Layout>
        </>
    )
}